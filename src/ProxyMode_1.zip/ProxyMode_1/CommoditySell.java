package ProxyMode_1;

public interface CommoditySell {
    void commodityOut();
}
